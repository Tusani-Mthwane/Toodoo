import imp
from attr import fields
from django.forms import ModelForm
from .models import Todo

class TodoForm(ModelForm):
    class Meta:
        model = Todo
        fields = '__all__'
        # fileds = ['surname', 'companyName', 'position', 'ispresent']