from turtle import position, title
from django.db import models
from django.contrib.auth.models import User

class Todo(models.Model):
    name = models.CharField(max_length=100)
    surname = models.CharField(max_length=100)
    companyName = models.TextField(blank=True)
    position = models.TextField(blank=True)
    startday = models.DateTimeField(auto_now_add=True)
    endday = models.DateTimeField(null=True, blank=True)
    ispresent = models.BooleanField(default=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    
    def __str__(self):
        return self.position